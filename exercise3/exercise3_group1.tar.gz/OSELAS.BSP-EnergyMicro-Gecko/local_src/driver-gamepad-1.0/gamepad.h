/*
 * This header defines useful addresses and constants needed for the 
 * gamepad driver.
 */

/* indices */
#define PLATFORM_MEM_INDEX_GPIO 0
#define PLATFORM_IRQ_INDEX_GPIO_EVEN 0
#define PLATFORM_IRQ_INDEX_GPIO_ODD 1

/* port bases */
#define GPIO_PA 0x00
#define GPIO_PB 0x24
#define GPIO_PC 0x48

/* register offsets */
#define GPIO_CTRL 0x00
#define GPIO_MODEL 0x04
#define GPIO_MODEH 0x08
#define GPIO_DOUT 0x0c
#define GPIO_DOUTSET 0x10
#define GPIO_DOUTCLR 0x14
#define GPIO_DOUTTGL 0x18
#define GPIO_DIN 0x1c
#define GPIO_PINLOCKN 0x20
#define GPIO_EXTIPSELL 0x100
#define GPIO_EXTIFALL 0x10c
#define GPIO_EXTIRISE 0x108
#define GPIO_IEN 0x110
#define GPIO_IFC 0x11c

