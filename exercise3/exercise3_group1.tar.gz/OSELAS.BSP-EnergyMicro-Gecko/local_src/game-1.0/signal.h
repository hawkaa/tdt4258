#ifndef SIGNAL_H_
#define SIGNAL_H_

extern int
button_signal_init(void);

extern int
timer_signal_init(void);

#endif
