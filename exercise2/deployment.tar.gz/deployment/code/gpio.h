#ifndef GPIO_H_
#define GPIO_H_

extern void
setupGPIO(void);

#endif
