#ifndef DAC_H_
#define DAC_H_

extern void
setupDAC(void);

#endif
